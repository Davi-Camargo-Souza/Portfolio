module Biblioteca {
    requires java.desktop;
}
